package jdbc;

import entities.Entity;

import java.util.List;

public class JDBCHelper {

    public static String INSERT_QUERY = "";

    public static String DELETE_QUERY = " ";

    public static String FIND_QUERY = " ";

    public static void insertElement(Entity entity) {}

    public static void deleteElement(Entity entity) {}

    public static void insertMultipleElements(List<Entity> entities) {}

    public static void deleteMultipleElements(List<Entity> entities) {}

    public static void findByName(String name) {

    }

    public static void findByUsername(String username) {}

}

package jdbc;

public class TestMainJDBC {
    public static void main(String[] args) {
         DBConnector.connectToDB();
    }
}
